package com.example.perf._2;

public class ProductNotFoundException extends Exception {
    	
	private static final long serialVersionUID =  292583730112873405L;

	public ProductNotFoundException() {
	}
}
